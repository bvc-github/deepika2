package com.pages;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.base.TestBase;

public class HomePage extends TestBase{
	public HomePage() throws IOException {
		//super();
	PageFactory.initElements(driver, this);
	}
	//Page Factory
	@FindBy(xpath="//a[@href='#tours']")
	WebElement tours;
	
	@FindBy(name = "date")
	WebElement startdate;
	
	@FindBy(className="input-lg form selectx")
	WebElement noofpersons;
	
	@FindBy(id="tourtype")
	WebElement tourtype;
	
	@FindBy(className="btn-primary btn btn-lg btn-block pfb0 loader")
	WebElement searchbtn;
	//Actions
	public String validateTitle() {
		return driver.getTitle();
	}
	public void toursMenu(){
	 { 
		 driver.findElement(By.xpath("tours")).click();
	 }
	 
	
	/*ublic ResultPage launch(String SearchText) throws IOException {
		searchbtn.click();
		return new ResultPage();
	}*/

	
	
	

	}
}
