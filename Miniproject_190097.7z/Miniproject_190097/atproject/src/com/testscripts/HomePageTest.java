package com.testscripts;

import org.testng.annotations.Test;


import com.base.TestBase;
import com.pages.HomePage;

import org.testng.annotations.BeforeMethod;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;

public class HomePageTest extends TestBase {
	HomePage homePage;
	public HomePageTest() throws IOException {
		super();
	}
	 @Test(priority=1)
	  public void validateTitleTest() {
		  String homePageTitle = homePage.validateTitle();
		  System.out.println("Page Title :" + homePageTitle);
		  Assert.assertEquals(homePageTitle, "Demo PHPTRAVELS");	  
	  }
	 @Test(priority=2)
	 public void toursMenuTest() throws Exception{
	 { 
		// System.out.println("tours menu");
			homePage.toursMenu();
			System.out.println("tours menu");

	 }
	 }
  @BeforeMethod
  	 public void setup() throws IOException {
			initialization();
			  homePage = new HomePage();
		  }
  


  @AfterMethod
  public void teardown() {
  }


}
