package com.base;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase {
	public static long PAGE_LOAD_TIMEOUT=20;
	public static long IMPLICIT_WAIT = 10;
	public static WebDriver driver;
	public static Properties prop;
	
	public TestBase() 
	{
		FileInputStream fin;
		prop = new Properties();
		try {
			fin =new FileInputStream(System.getProperty("user.dir")+"/src/com/config/config.properties");
			prop.load(fin);
		} catch (IOException e) {
		
			e.printStackTrace();
		}		
	}
	public static void initialization() {
        String browserName=prop.getProperty("Browser");
        if(browserName.equalsIgnoreCase("chrome")) {
            System.setProperty("webdriver.chrome.driver", "C:\\Users\\desuram\\Desktop\\chromedriver.exe");
            driver = new ChromeDriver();
        }
        if(browserName.equalsIgnoreCase("firefox")) {
           
        }
        if(browserName.equalsIgnoreCase("explorer")) {
        }
        driver.manage().window().maximize();
        driver.manage().deleteAllCookies();
       // driver.manage().timeouts().pageLoadTimeout(PAGE_LOAD_TIMEOUT, TimeUnit.SECONDS);
       // driver.manage().timeouts().implicitlyWait(IMPLICIT_WAIT, TimeUnit.SECONDS);
        System.out.println("enter url");
        driver.get(prop.getProperty("URL"));
        System.out.println("page launch");
    } 
}
	
	
	 



